<?php
class zk_common_model extends My_Model{

    public function __construct(){
        parent:: __construct();
    }


    //---  function for getting records  ---//
    public function get_records($result ,$table, $columns, $where = '',$orderBy = '', $groupBy = '', $skip = '', $take = ''){
        $this->db->select($columns);
        $this->db->from($table);
        if($where != ''){
            $this->db->where($where);
        }
        if($orderBy != '')
            $this->db->order_by($orderBy);
        if($groupBy != '')
            $this->db->group_by($groupBy);
        if($skip != '' && $take != '')
            $this->db->limit($take, $skip);
        $query = $this->db->get();
        return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
    }//---  End of function get_records  ---//


    //---  function for counting records  ---//
    public function count_get_records($table, $columns, $where = '',$groupBy = ''){
        $this->db->select($columns);
        $this->db->from($table);
        if($where != ''){
            $this->db->where($where);
        }
        if($groupBy != '')
            $this->db->group_by($groupBy);
        $query = $this->db->get();
        return $query->num_rows();
    }//---  End of function count_get_records  ---//


   //---  function for getting multi filter records  ---//
   public function get_multi_filter_records($result, $table, $columns, $where= '', $orderBy = '',$groupBy='', $skip= '', $take='',$likes = ''){
        $this->db->select($columns);
        $this->db->from($table);
        if($where != '')
            $this->db->where($where);
       if($orderBy != '')
           $this->db->order_by($orderBy);
       if($groupBy != '')
           $this->db->group_by($groupBy);
       if($likes != ''){
           foreach($likes as $like){
               $this->db->like($like['field'], $like['value']);
           }
       }
       if($skip != '' && $take != '')
            $this->db->limit($take, $skip);
        $query = $this->db->get();
       return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
   }//---  End of function get_multi_filter_records  ---//


    //---  function for counting multifilter records  ---//
    public function count_multi_filter_records($table, $columns, $where= '',$groupBy='',$likes = ''){
        $this->db->select($columns);
        $this->db->from($table);
        if($where != '')
            $this->db->where($where);
        if($groupBy != '')
            $this->db->group_by($groupBy);

        if($likes != ''){
            foreach($likes as $like){
                $this->db->like($like['field'], $like['value']);
            }
        }
        $query = $this->db->get();
        return $query->num_rows();
    }//---  End of function count_multi_filter_records  ---//


    //---  function for getting joined records  ---//
    public function get_joined_records($result, $pTable, $columns, $joins, $where = '',$orderBy = '',$groupBy='', $skip = '', $take = ''){
        $this->db->select($columns);
        $this->db->from($pTable);
        foreach($joins as $join){
            $this->db->join($join['table'],$join['condition'], $join['joinType']);
        }
        if($where != ''){
            $this->db->where($where);
        }
        if($orderBy != '')
            $this->db->order_by($orderBy);
        if($groupBy != '')
            $this->db->group_by($groupBy);
        if($skip != '' && $take != '')
            $this->db->limit($take, $skip);
        $query = $this->db->get();
        return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
    }//---  End of function get_joined_records  ---//


    //---  function for counting joined records  ---//
    public function count_joined_records($pTable, $columns, $joins, $where = '',$groupBy = ''){
        $this->db->select($columns);
        $this->db->from($pTable);
        foreach($joins as $join){
            $this->db->join($join['table'],$join['condition'], $join['joinType']);
        }
        if($where != ''){
            $this->db->where($where);
        }
        if($groupBy != '')
            $this->db->group_by($groupBy);
        $query = $this->db->get();
        return $query->num_rows();
    }//---  End of function count_joined_records  ---//


    //---  function for getting multi filtered joined records  ---//
    public function get_joined_multi_filter_records($result,$pTable, $columns, $joins='', $where= '', $orderBy = '',$groupBy='', $skip= '', $take='',$likes = ''){
        $this->db->select($columns);
        $this->db->from($pTable);
        if($joins != '')
        {
            foreach($joins as $join){
                $this->db->join($join['table'],$join['condition'], $join['joinType']);
            }
        }
        if($where != '')
            $this->db->where($where);
        if($orderBy != '')
            $this->db->order_by($orderBy);
        if($groupBy != '')
            $this->db->group_by($groupBy);

        if($likes != ''){
            foreach($likes as $like){
                $this->db->like($like['field'], $like['value']);
            }
        }
        if($skip != '' && $take != '')
            $this->db->limit($take, $skip);
        $query = $this->db->get();
        return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
    }//---  End of function get_joined_multi_filter_records  ---//


    //---  function for counting multi filtered joined reocrds  ---//
    public function count_joined_multi_filter_records($pTable, $columns, $joins='', $where= '',$groupBy='', $likes= ''){
        $this->db->select($columns);
        $this->db->from($pTable);
        if($joins != '')
        {
            foreach($joins as $join){
                $this->db->join($join['table'],$join['condition'], $join['joinType']);
            }
        }
        if($where != '')
            $this->db->where($where);
        if($groupBy != '')
            $this->db->group_by($groupBy);
        if($likes != ''){
            foreach($likes as $like){
                $this->db->like($like['field'], $like['value']);
            }
        }
        $query = $this->db->get();
        return $query->num_rows();
    }//---  End of function count_joined_multi_filter_records  ---//


    //---  function for getting autocomplete records  ---//
    public function get_autocomplete_records($result, $table, $columns, $likes = '', $where='',$orderBy = '', $groupBy = ''){
        $this->db->select($columns);
        $this->db->from($table);
        if($where != '')
            $this->db->where($where);
        if($orderBy != '')
            $this->db->order_by($orderBy);
        if($groupBy != '')
            $this->db->group_by($groupBy);
        if($likes != ''){
            foreach($likes as $like){
                $this->db->like($like['field'], $like['value']);
            }
        }
        $query = $this->db->get();
        return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
    }//---  End of function get_autocomplete_records  ---//


    //---  function for getting autocomplete records with joins  ---//
    public function get_autocomplete_joined_records($result, $pTable, $columns,$joins,$where = '', $likes = '',$groupBy = ''){
        $this->db->select($columns);
        $this->db->from($pTable);
        foreach($joins as $join){
            $this->db->join($join['table'],$join['condition'], $join['joinType']);
        }
        if($where != '')
            $this->db->where($where);
        if($groupBy != '')
            $this->db->group_by($groupBy);
        if($likes != ''){
            foreach($likes as $like){
                $this->db->like($like['field'], $like['value']);
            }
        }
        $query = $this->db->get();
        return $result = ($result == RESULT_OBJECT) ? $query->result() : $query->result_array();
    }//---  End of function get_autocomplete_joined_records  ---//


    //---  function for inserting new records  ---//
    public function insert_record($table, $data){
        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }//---  End of function insert_reocord  ---//


    //---  function for inserting multiple records in batch form  ---//
    function insert_multiple($tbl,$data)
    {
        $this->db->insert_batch($tbl, $data);
    }//---  End of function insert_multiple  ---//


    //---  function for updating records  ---//
    public function update_records($table, $data, $where = ''){
        $this->db->trans_start();

        if($where != '')
            $this->db->where($where);
        $this->db->update($table, $data);

        $this->db->trans_complete();
        if($this->db->trans_status()  === false){
            return false;
        }else{
            return true;
        }

    }//---  end of function update_records  ---//


    //---  function for deleting records  ---//
    public function delete_records($table,$where = ''){
        if($where != '')
            $this->db->where($where);
        $this->db->delete($table);
        $affectedRows = $this->db->affected_rows();
        if($affectedRows){
            return true;
        }else{
            return false;
        }
    }//---  End of function delete_records  ---//


   //---  function for truncating table  ---//
   public function truncate_table($table){
       $this->db->truncate($table);
       $affectedRows = $this->db->affected_rows();
       if($affectedRows){
           return true;
       }else{
           return false;
       }
   }//---  End of function truncate_table  ---//


}//---  End of class zk_common_model  ---//