<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Common_model extends CI_Model{

  function __construct()
    {
        parent::__construct();
    }
	
	//------------------------ Select record queries -----------------------------------

	 function select($tbl = '')
	 {
		 $query = $this->db->get($tbl);
         return $query->result();

     }

    function select_fields($tbl = '', $data)
    {
        $this->db->select($data);
        $query = $this->db->get($tbl);
        //return $this->db->last_query();
        return $query->result();
    }

    function select_dist_fields($tbl = '', $data,$where='',$joins='',$group_by='')
    {
        $this->db->distinct();
        $this->db->select($data);
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if(!''==$where){
            $this->db->where($where);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        $query = $this->db->get($tbl);
        //return $this->db->last_query();
        return $query->result();
    }

    function select_fields_joined($data, $PTable, $joins='',$where='')
    {
        $this->db->select($data);

        $this->db->from($PTable);
        if($joins!=''){
        foreach ($joins as $k => $v){
            $this->db->join($v['table'], $v['condition'], $v['jointype']);
        }
        }
        if($where!='')
        {
            $this->db->where($where);
        }

        $query = $this->db->get();
        return $query->result();
    }

    function select_distinct_fields($tbl = '')
    {
        $this->db->order_by('PuID','desc');
        $this->db->group_by('PuCode');
        $this->db->distinct('PuCode');
        $query = $this->db->get($tbl);
        return $query->result();
    }

    function select_GridsWithPagingAndFiltering($tbl = '', $data, $skip, $take, $logic, $field, $operator, $value, $where='',$order_by='',$joins='')
    {
        $this->db->select($data);
        if($joins!==''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!= ''){
            $this->db->where($where);
        }
        $this->db->limit($take, $skip);

        $this->db->like($field, $value);
        if($tbl == "osp_material_price"){
            $this->db->order_by("MaterialPriceID", "desc");
        }
        if($order_by!= '')
        {
            $this->db->order_by($order_by);
        }
        $query = $this->db->get($tbl);
       // echo $this->db->last_query();
        return $query->result();
    }

    function select_GridsWithPagingAndFilteringJoined($columns, $PTable, $joins='', $skip, $where= '', $take, $logic, $field, $operator, $value='', $group_by='',$isNull='',$order_by='')
    {
        $this->db->select($columns);
        $this->db->from($PTable);

        if($joins!==''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }

        if($where!=''){
            $this->db->where($where);
        }
        if(''===$isNull && ''!==$value){
            $this->db->like($field, $value);
        }else if($isNull == '0' && ''==$value){
            $this->db->where($field.' IS NULL',null);
        }else if($isNull == '1' && ''==$value){
            $this->db->where($field.' IS NOT NULL',null);
        }
        if($skip!='' || $take!='')
        {
        $this->db->limit($take, $skip);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($order_by!=''){
            $this->db->order_by($order_by);
        }

        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }


    function get_list_emp($tbl, $data, $array, $take = '', $skip = ''){
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where_in('EmployeeID',$array);

        if($take != '' && $skip != ''){
            $this->db->limit($take, $skip);
        }
        $query = $this->db->get();
        return $query;
    }

   function count_list_emp($tbl, $data, $array){
       $this->db->select($data);
       $this->db->from($tbl);
       $this->db->where_in('EmployeeID',$array);
       $query = $this->db->get();
       return $query->num_rows();
   }

    function select_GridsWithPagingAndFiltering_DailyReport($data, $skip, $take, $logic, $field, $operator, $from_date, $to_date,$f_no)
    {
        $where_clause_array = array('EmployeeNumber' => $f_no, 'Dated >=' => date('Y-m-d',strtotime($from_date)), 'Dated <=' => date('Y-m-d',strtotime($to_date)));
        $this->db->select($data);
        $this->db->from('hr_employee_attendance');
        $this->db->limit($take, $skip);
        $this->db->where($where_clause_array);
        $query = $this->db->get();
        return $query->result();
    }


    function select_GridsWithPaging($tbl = '', $data, $skip, $take,$where='',$order_by='')
    {
        $this->db->select($data);
        $this->db->limit($take, $skip);
        //$query = $this->db->get($tbl);
        if($tbl === 'hr_employee_details'){
            $this->db->where('IsActive',1);
        }
        if(!(''===$where)){
            $this->db->where($where);
        }
        if($tbl == "osp_material_price"){
            $this->db->order_by("MaterialPriceID", "desc");
        }
        if($order_by!= '')
        {
            $this->db->order_by($order_by);
        }
        $query = $this->db->get($tbl);
        //echo $this->db->last_query();
        return $query->result();
    }


    function select_GridsWithPagingJoinedTables_flimzi_details($InvoiceID, $ClientID, $PuYear){
        $sql = 'SELECT
                ifd."InvoiceID",
                ifd."InvoiceDetailsID",
                ifd."JobID",
                ifd."Description",
                ifd."Quantity",
                ifd."PuCode",
                ojd."OurJobNumber",
                opc."PuCode",
                opc."PuUnitPrice",
                opc."PuUnitPrice" * "Quantity" AS "SubTotal"
                FROM osp_invoice_flimzi_details ifd
                INNER JOIN osp_job_details ojd ON (ojd."JobID" = ifd."JobID")
                INNER JOIN osp_pu_codes opc ON (opc."PuCode" = ifd."PuCode")
                WHERE ifd."InvoiceDetailsID" NOT IN (
                  SELECT iffd."InvoiceDetailsID" FROM osp_invoice_flimzi_details ifd
                  INNER JOIN  osp_final_invoice_flimzi_details iffd
                  ON ifd."PuCode" = iffd."PuCode" AND ifd."Description" = iffd."Description"
                )
                AND ifd."InvoiceID" = '.$InvoiceID.'
                AND opc."OSPClientID" = '.$ClientID.'
                AND opc."PuYear" = '.$PuYear;
        $query = $this->db->query($sql);
        return $query->result();
    }

    function count_total_record_for_flimzi($InvoiceID, $ClientID, $PuYear){
        $sql = 'SELECT
                ifd."InvoiceID",
                ifd."InvoiceDetailsID",
                ifd."JobID",
                ifd."Description",
                ifd."Quantity",
                ifd."PuCode",
                ojd."OurJobNumber",
                opc."PuCode",
                opc."PuUnitPrice",
                opc."PuUnitPrice" * "Quantity" AS "Total"
                FROM osp_invoice_flimzi_details ifd
                INNER JOIN osp_job_details ojd ON (ojd."JobID" = ifd."JobID")
                INNER JOIN osp_pu_codes opc ON (opc."PuCode" = ifd."PuCode")
                WHERE ifd."InvoiceDetailsID" NOT IN (
                  SELECT iffd."InvoiceDetailsID" FROM osp_invoice_flimzi_details ifd
                  INNER JOIN  osp_final_invoice_flimzi_details iffd
                  ON ifd."PuCode" = iffd."PuCode" AND ifd."Description" = iffd."Description"
                )
                AND ifd."InvoiceID" = '.$InvoiceID.'
                AND opc."OSPClientID" = '.$ClientID.'
                AND opc."PuYear" = '.$PuYear;
        $query = $this->db->query($sql);
        return $query->num_rows();
    }

    function get_autoCompleteJoinForFlimziDetails($InvoiceID, $PuYear, $ClientID, $Field, $value){
        $sql = 'SELECT
                ifd."InvoiceID",
                ifd."InvoiceDetailsID",
                ifd."JobID",
                ifd."Description",
                ifd."Quantity",
                ifd."PuCode",
                ojd."OurJobNumber",
                opc."PuCode",
                opc."PuUnitPrice",
                opc."PuUnitPrice" * "Quantity" AS "SubTotal"
                FROM osp_invoice_flimzi_details ifd
                INNER JOIN osp_job_details ojd ON (ojd."JobID" = ifd."JobID")
                INNER JOIN osp_pu_codes opc ON (opc."PuCode" = ifd."PuCode")
                WHERE ifd."InvoiceDetailsID" NOT IN (
                  SELECT iffd."InvoiceDetailsID" FROM osp_invoice_flimzi_details ifd
                  INNER JOIN  osp_final_invoice_flimzi_details iffd
                  ON ifd."PuCode" = iffd."PuCode" AND ifd."Description" = iffd."Description"
                )
                AND ifd."InvoiceID" = '.$InvoiceID.'
                AND opc."OSPClientID" = '.$ClientID.'
                AND opc."PuYear" = '.$PuYear;
                $sql.=" AND $Field  LIKE '%".$value."%'";



        $query = $this->db->query($sql);
        return $query->result();
    }

    function select_GridsWithPagingJoinedTables( $columns, $PTable, $joins='', $where='', $take='', $skip='', $order='',$group_by='',$where_in_filed='',$where_in_array=''){

        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype'],FALSE);
            }
        }
        if($where != ''){
            $this->db->where($where);
        }
        if($where_in_array != ''){
            $this->db->where_in($where_in_filed,$where_in_array);
        }
        if($take!='' && $skip!=''){
        $this->db->limit($take, $skip);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($order!=''){
            $this->db->order_by($order);
        }
        $query = $this->db->get();
        //echo  $this->db->last_query();
        return $query->result();
    }

    function select_GridsWithPagingJoinedTablesAggregates( $columns, $PTable, $joins='', $where='', $take, $skip,$order='',$group_by=''){
        $result_array= array();

        $this->db->select($columns);

        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        $this->db->limit($take, $skip);
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($order!=''){
            $this->db->order_by($order);
        }

        $result_array = $this->db->get();
       // echo  $this->db->last_query();
        return $result_array->result();
    }//end of select_GridsWithPagingJoinedTablesAggregates

    function select_GridsWithPagingJoinedTables2( $columns, $PTable, $joins, $where='', $take, $skip,$order=''){
        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        foreach ($joins as $k => $v){
            $this->db->join($v['table'], $v['condition'], $v['jointype']);
        }
        $this->db->group_by('osp_job_survey_civil.JobID');
        if($where!=''){
            $this->db->where($where);
        }
        $this->db->limit($take, $skip);
        $this->db->order_by('osp_job_survey_civil.SurveyID','DESC');


        $query = $this->db->get();
        echo $this->db->last_query();
        //return $query->result();
    }

    function countTotalRecords($columns, $PTable, $joins='', $where='',$field1='',$value1='',$group_by='',$isNull='',$where_in_filed='',$where_in_array=''){
        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($where_in_array !=''){
            $this->db->where_in($where_in_filed,$where_in_array);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if(''===$isNull){
        if($field1!='' && $value1!=''){
            $this->db->like($field1, $value1);
        }
        }
        else if($isNull == 0){
            $this->db->where($field1.' IS NULL',null);
        }else if($isNull == 1){
            $this->db->where($field1.' IS NOT NULL',null);
        }

        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->num_rows();
    }

    function totalAggregate($PTable, $column1='', $column2='', $joins='',$where='',$field='',$value=''){

        $this->db->select(' SUM('.$column1.' * '.$column2.') AS "TotalCost" ');
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($field!='' && $value!=''){
            $this->db->like($field,$value);
        }
        $query = $this->db->get();
        $result = $query->result_array();

        //echo $this->db->last_query();
        return $result[0]['TotalCost'];
    }
    //-------------------------
    function select_GridsWithPagingAndFiltering_JoinedTable($data='', $PTable='', $joins='', $skip='', $take='', $logic='', $field='', $operator='', $value='',$where='',$order_by='')
    {
        $this->db->select($data);
        $this->db->from($PTable);
        if($joins != ""){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($order_by != ''){
            $this->db->order_by($order_by);
        }
        if($PTable === 'hr_employee_details'){
            $this->db->where('IsActive',0);
        }
        $this->db->limit($take, $skip);
        $this->db->like($field, $value);
        $query = $this->db->get();
        return $query->result();
    }
    //-------------------------

    function select_GridsWithPaging_WhereClause($tbl = '', $data, $skip, $take,$file_no)
    {
        $this->db->select($data);
        $this->db->limit($take, $skip);
        $this->db->where('EmployeeNumber',$file_no);
        $query = $this->db->get($tbl);
        return $query->result();
    }
	 //----------------  select records on condition basis ------------------------------
	 function get_records($tbl,$data,$field='',$id='',$order_by='')
	 {
		 $this->db->select($data);
		 $this->db->from($tbl);
         if(($field != '') && ($id!= '')){
             $this->db->where($field,$id);
         }
         if($order_by != ''){
             $this->db->order_by($order_by);
         }
		 return $query = $this->db->get();
	 }

    function get_records_for_employee($tbl,$data,$field,$id)
    {
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where($field,$id);
        $this->db->order_by('IsActive','desc');
        if($tbl == 'hr_emplyee_work_permit_details')
        {
            $this->db->order_by('IssueDate','asc');
        }

        return $query = $this->db->get();
    }

    function get_autoComplete($tbl, $data, $field, $value, $where='',$limit=''){
        $this->db->select($data);
        $this->db->from($tbl);
        if($where!=''){
            $this->db->where($where);
        }
        if($field !== '' && $value !== ''){
            $this->db->like($field, $value);
        }
        //$this->db->group_by($field);
        if($limit !='')
        {
            $this->db->limit($limit);
        }
        $query=$this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }

    function get_autoCompleteJoin($PTable, $joins='', $condition='', $data, $field, $value){
        $this->db->select($data);
        $this->db->from($PTable);
        if($joins != ""){
        foreach ($joins as $k => $v){
            $this->db->join($v['table'], $v['condition'], $v['jointype']);
        }
        }
        if($condition!=''){
        $this->db->where($condition);
        }
        $this->db->like($field, $value);
        //$this->db->group_by($field);
        $query=$this->db->get();
        //echo $this->db->last_query();
        return $query->result();
    }

    function get_where_records($tbl,$data,$where='',$where_in='',$orderby="",$WhereInField='',$WhereNotInField='',$WhereNotArray='',$like='')
	 {
		 $this->db->select($data);
		 $this->db->from($tbl);
         if($where!="")
         {
		    $this->db->where($where);
         }
         if($orderby!=""){
             $this->db->order_by($orderby);
         }
         if($where_in != ''){
             $this->db->where_in($WhereInField,$where_in);
         }
         if($WhereNotArray != ''){
             $this->db->where_not_in($WhereNotInField,$WhereNotArray);
         }

         if($like!="")
         {
             $this->db->like($like);
         }
		 $query = $this->db->get();
         return $query->result();
	 }

    function selectClientProjects($ClientField='', $ClientID=''){
        $sql = "SELECT ProjectID, ProjectName, ProjectNumber FROM osp_clients_projects ";
        if($ClientID !=="" && $ClientField !== ""){
            $sql .= " WHERE {$ClientField}={$ClientID}";
        }
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    function get_where_records_array($tbl,$data,$array)
    {
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where($array);
        $query = $this->db->get();
        return $query->result_array();
    }

    function get_where_records_joined($PTable='',$data='',$where='', $joins='',$group_by='',$order_by=''){
        $this->db->select($data);
        $this->db->from($PTable);
        if($joins != ""){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if(!''==$where){
        $this->db->where($where);
        }
        if(!''==$group_by){
           $this->db->group_by($group_by);
        }
        if(!''==$order_by){
            $this->db->order_by($order_by);
        }
        return $query = $this->db->get()->result();
    }

    function  get_joined_records_where($PTable,$data,$array, $joins){
        $this->db->select($data);
        $this->db->from($PTable);

        foreach ($joins as $k => $v){
            $this->db->join($v['table'], $v['condition'], $v['jointype']);
        }
        $this->db->where($array);
        return $query = $this->db->get()->result_array();
    }

    function get_where_records_asc($tbl, $data, $array, $field)
    {
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where($array);
        $this->db->order_by($field,'asc');
        $query = $this->db->get();
        return $query->result();

    }

    function get_records_desc($tbl, $data, $field){
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->order_by($field,'desc');
        return $query = $this->db->get();
    }

    function get_records_desc_single($tbl, $data, $field){
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->limit(1);
        $this->db->order_by($field,'desc');
        return $query = $this->db->get();
    }

    function get_user_groups($UserID){
        $this->db->select();
        $this->db->from('sys_user_accounts');
        $this->db->join('sys_user_groups_memberships','sys_user_accounts.UserID = sys_user_groups_memberships.UserID', 'INNER');
        $this->db->join('sys_user_groups','sys_user_groups_memberships.GroupID = sys_user_groups.GroupID', 'INNER');
        $this->db->WHERE('sys_user_accounts.UserID', $UserID);
        $query = $this->db->get();
        return $query->result();
    }

	function get_where_in($tbl,$data,$array,$field)
	 {
		  $this->db->select($data);
		  $this->db->from($tbl);
		  $this->db->where_in($field,$array);
		  return $query = $this->db->get();
	 }

    function count_get_where_in($tbl,$data,$array,$field){
        $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where_in($field,$array);
         $query = $this->db->get();
        return $query->num_rows();
    }
	//------------------------ insert record queries ----------------------------------- 
	 function insert_record($tbl,$data)
	 {
		 $this->db->insert($tbl, $data);
		 return $this->db->insert_id();
     }

     function insert_multiple($tbl,$data)
	 {
		 $this->db->insert_batch($tbl, $data);
	 }
	 
	 //------------------------ update record queries -----------------------------------
    function update($tbl, $fields, $data){

        $this->db->where($fields);
        $this->db->update($tbl, $data);
        if($this->db->affected_rows() > 0){
            return true;
        }else{
            return false;
        }
    }

	function update_query($tbl,$field,$id,$data)
	  {
			$this->db->where($field, $id);
			$this->db->update($tbl, $data);
            //echo $this->db->last_query();
           $affectedRows = $this->db->affected_rows();
              if($affectedRows){
                  return $affectedRows;
              }
              else{
                  return $this->db->_error_message();
              }

	  }


    function update_query_array($tbl,$fields,$data)
    {

        $this->db->where($fields);
        $this->db->update($tbl, $data);
        $afftectedRows = $this->db->affected_rows();
       //return $this->db->last_query();

        if($afftectedRows){
            return $afftectedRows;
        }
        else{
            return $this->db->_error_message();
        }

    }
	 //------------------------ Delete record queries ----------------------------------- 
	function delete($tbl,$condition)
	 {
		 $this->db->delete($tbl, $condition);
         if ($this->db->affected_rows() > 0){
             return TRUE;
         }
         else {
             //return FALSE;
            return FALSE;
         }
	 }

    function truncate_tbl($tbl)
	 {
		 $this->db->truncate($tbl);
	 }
    //getting specific employee Record
    function select_employee($EmployeeID)
    {
        $this->db->select(array('hr_employee_details.*','acc_detail_account.HeadID'));
        $this->db->join('acc_detail_account','acc_detail_account.DetailAccID = hr_employee_details.DetailAccID','INNER');
        $query = $this->db->get_where('hr_employee_details',array('EmployeeID' => $EmployeeID));
        return $query->result();
    }
    //getting last attendance record
    function select_last_att($tbl, $data, $field, $id){
       $this->db->select($data);
        $this->db->from($tbl);
        $this->db->where($field, $id);
        $this->db->order_by('AttendanceID', 'desc');
        $this->db->limit(1);
        $query = $this->db->get();
        return $query->result();
    }

    /*function ruf_func($tbl, $from_date, $to_date)
    {
      $query = $this->db->query("Select * from hr_employee_attendance WHERE  Dated>= '$from_date' and Dated<= '$to_date' order by Dated asc");
         return $query->result();

    }*/

    function get_num_of_present($tbl, $from_date, $to_date, $FileNo)
    {
        $where = array(
                 "EmployeeNumber" => $FileNo,
                 "Dated >="        => $from_date,
                 "Dated <="        => $to_date,
                );
        $this->db->where($where);
        $this->db->order_by('Dated ASC');
        $query = $this->db->get('hr_employee_attendance');
        //$query = $this->db->query("Select * from hr_employee_attendance
        //WHERE EmployeeNumber = $FileNo and Dated>= '$from_date' and Dated<= '$to_date' order by Dated asc");
        return $query->num_rows();
    }

    function get_employee_details($EmployeeID){//this function should be placed in hr_management later
                                                     //hr employees details
        $this->db->select();
        $this->db->from('hr_employee_details');
        $this->db->join('sys_country_names', 'hr_employee_details.CountryID = sys_country_names.CountryID', 'LEFT');
        $this->db->join('sys_gender', 'hr_employee_details.GenderID = sys_gender.GenderID', 'LEFT');
        $this->db->join('hr_marital_status', 'hr_employee_details.MaritalStatsID = hr_marital_status.MaritalStatusID', 'LEFT');
        $this->db->join('hr_positions', 'hr_employee_details.PositionID = hr_positions.PositionID', 'LEFT');
        $this->db->join('hr_departments', 'hr_employee_details.DepartmentID = hr_departments.DepartmentID', 'LEFT');
            $this->db->where('hr_employee_details.EmployeeID', $EmployeeID);
        //$this->db->join('hr_employee_bank_details', 'hr_employee_details.EmployeeID = hr_employee_bank_details.EmployeeID', 'INNER');

        $query = $this->db->get();
        return $query;
    }

    function get_employee_dependants($EmployeeID){
        $this->db->select();
        $this->db->from('hr_employee_details');
        $this->db->join('hr_employee_dependents', 'hr_employee_details.EmployeeID = hr_employee_dependents.EmployeeID', 'INNER');
        $this->db->join('hr_dependents_relationships', 'hr_employee_dependents.RelationID = hr_dependents_relationships.RelationshipID', 'INNER');
        $this->db->where('hr_employee_details.EmployeeID', $EmployeeID);
        $query = $this->db->get();
        return $query;
    }

    //=====================================================
    function select_GridsWithPagingAndFiltering_join($tbl='',$join_array, $data, $skip, $take, $logic, $field, $operator, $value)
    {

        $this->db->select($data);
        $this->db->from($tbl);
        foreach($join_array as $join) :
            $this->db->join($join['table'],$join['table'].'.'.$join['field'].' = '.$tbl.'.'.$join['field']);
        endforeach;
        $this->db->limit($take, $skip);
        $this->db->like($field, $value);
        $query = $this->db->get();
        return $this->db->last_query();
        //return $query->result();
    }//end of select_GridsWithPagingAndFiltering_join

    function select_GridsWithPaging_join($tbl = '',$join_array, $data, $skip, $take,$condition='',$groupby='')
    {
        $this->db->select($data);
        $this->db->from($tbl);
        foreach($join_array as $join) :
          $this->db->join($join['table'],$join['table'].'.'.$join['field'].' = '.$tbl.'.'.$join['field'],$join['join_type']);
        endforeach;

        if(!''==$condition){
            $this->db->where($condition);
        }
        if(!''==$groupby){
            $this->db->group_by($groupby);
        }
        //$this->db->join('sys_roles_list','sys_roles_list.RoleID = '.$tbl.'.RoleID','left');
        $this->db->limit($take, $skip);
        $query = $this->db->get();

        return $query->result();
    }//end of select_GridsWithPaging_join


    function countRecByID($ID, $Table ,$where = ''){
        $this->db->select($ID);
        $this->db->distinct();
        $this->db->from($Table);
        if(!''==$where){
            $this->db->where($where);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    function countRecByValue($ID, $Table, $field1, $value1){
        $this->db->select($ID);
        $this->db->distinct();
        $this->db->from($Table);
        $this->db->like($field1, $value1);
        $query = $this->db->get();
        return $query->num_rows();
    }

    function countJoinedRec($data, $PTable, $joins='', $array='',$groupby=''){
        $this->db->select($data);

        $this->db->from($PTable);
        if(!(''===$joins)){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($array != ""){
        $this->db->where($array);
        }
        if(!''==$groupby){
            $this->db->group_by($groupby);
        }
        $query = $this->db->get();
        return $query->num_rows();
    }

    function select_materials_allocation_table( $columns, $PTable, $joins='', $where='', $take= '', $skip='', $order='',$group_by='',$SubTable,$SubColumn,$reallocate='',$field='',$value=''){
        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($field !=='' && $value !==''){
            $this->db->like($field,$value);
        }
        if($take != ''){
            $this->db->limit($take, $skip);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($order!=''){
            $this->db->order_by($order);
        }
        $query = $this->db->get();
        //echo  $this->db->last_query();
        $result_array = array();
        foreach($query->result() as $key=>$row){
            array_push($result_array,$row);
            $this->db->select('SUM("'.$SubColumn.'") AS "'.$SubColumn.'" ');
            $this->db->where(array('OMRequestID'=>$row->OMRequestID));
            $subquery = $this->db->get($SubTable);
            $subquery = $subquery->result_array();
            $result_array[$key]->$SubColumn = $subquery[0][$SubColumn];
            if(!(''==$reallocate)){
                $this->db->select('SUM("ReallocatedQuantity") AS "ReallocatedQuantity" ');
                $this->db->where(array('OMRequestID'=>$row->OMRequestID));
                $subquery2 = $this->db->get('osp_materials_reallocation');
                $subquery2 = $subquery2->result_array();
                $result_array[$key]->ReallocatedQuantity = $subquery2[0]['ReallocatedQuantity'];
            }
        }
       // return $query->result();
        return $result_array;
    }//end of select_materials_allocation_table
    function flimzi_work_orders(){
        $sql = "SELECT q.* FROM  (
            SELECT oif.*, wo.WorkOrderNumber,
(SELECT
 GROUP_CONCAT(`jobID` SEPARATOR ',') FROM `osp_job_details` WHERE  `osp_job_details`.`WorkOrderID`=oif.`WorkOrderID` GROUP BY `osp_job_details`.`WorkOrderID`) AS Alljobids
 , GROUP_CONCAT(j.`jobID` SEPARATOR ',') AS onlystatusids
FROM `osp_invoice_flimzi` oif INNER JOIN `osp_job_details` j ON (oif.`WorkOrderID` = j.`WorkOrderID`)
LEFT JOIN `osp_projects_work_order` wo ON (oif.`WorkOrderID` = wo.`WorkOrderID`)
INNER JOIN `osp_job_status_track` js ON (j.`jobID` = js.`jobID`) WHERE js.`StatusID`=9

GROUP BY oif.`WorkOrderID`) q WHERE  q.Alljobids=q.onlystatusids";
        $query = $this->db->query($sql);
        return $query->result();
    }

    function flimzi_total_work_orders(){
        $sql = "SELECT q.* FROM  (
            SELECT oif.*, wo.WorkOrderNumber,
(SELECT
 GROUP_CONCAT(`jobID` SEPARATOR ',') FROM `osp_job_details` WHERE  `osp_job_details`.`WorkOrderID`=oif.`WorkOrderID` GROUP BY `osp_job_details`.`WorkOrderID`) AS Alljobids
 , GROUP_CONCAT(j.`jobID` SEPARATOR ',') AS onlystatusids
FROM `osp_invoice_flimzi` oif INNER JOIN `osp_job_details` j ON (oif.`WorkOrderID` = j.`WorkOrderID`)
LEFT JOIN `osp_projects_work_order` wo ON (oif.`WorkOrderID` = wo.`WorkOrderID`)
INNER JOIN `osp_job_status_track` js ON (j.`jobID` = js.`jobID`) WHERE js.`StatusID`=9

GROUP BY oif.`WorkOrderID`) q WHERE  q.Alljobids=q.onlystatusids";
        $query = $this->db->query($sql);

        return $query->num_rows();
    }

    function Aggregatefunc($PTable, $column1='', $joins='',$where='',$like='',$having='',$columns =''){

        $this->db->select(" SUM(".$column1.") AS \"Total\"");
        if($columns !== ""){
            $this->db->select($columns);
        }
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($like!=''){
            $this->db->like($like);
        }
        if($having !== ''){
            $this->db->having($having,'',FALSE);
        }
        $query = $this->db->get();
        $result = $query->result_array();

        //echo $this->db->last_query();
        if(isset($result[0])){
            return $result[0]['Total'];
        }else{
            return 0;
        }

    }

    //---  function for updating job status  ---//
    public function update_job_status($jobID, $statusID, $subStatusID){
        $userID = end(explode("-",$this->nativesession->get('UserID')));
        $table = 'osp_job_status_track';

        //---  checking whether status already exist or not (if exist do nothing return true) ---//
        $jobStatus = array(
            'JobID'=> $jobID,
            'StatusID'=> $statusID,
            'CurrentStatus'=> $subStatusID
            //'isDefault'=>1
        );
        $this->db->select(array('JobID'));
        $this->db->from($table);
        $this->db->where($jobStatus);
        $statusResultSet = $this->db->get();
        $status = $statusResultSet->result();
        if(isset($status[0]->JobID)){
            return true;
        }

        //---  transaction begins here  ---//
        $this->db->trans_begin();
        $where = array(
            'JobID'=> $jobID,
            'isDefault' => 1
        );

        $this->db->where($where);
        $this->db->update($table, array('isDefault' => 0));

        $statusInfo = array(
            'JobID'=> $jobID,
            'StatusID'=> $statusID,
            'CurrentStatus'=>$subStatusID,
            'StatusTrackDate' => date('Y-m-d'),
            'UserID'=> $userID,
            'isDefault'=> 1
        );
        $this->db->insert($table, $statusInfo);

        if($this->db->trans_status()  ===  false){
            $this->db->trans_rollback();
            return false;
        }else{
            $this->db->trans_commit();
            return true;
        }
    }//---  End of function update_job_status  ---//


    //===============================================
    //***** HEAD CODE
    function getAccountCode($where){
        $this->db->select(array('HeadCode','ParentID'));
        $this->db->where($where);
        $query = $this->db->get('acc_heads');
        $head  = $query->result_array();
        $Code = $head[0]["HeadCode"];
        if($head[0]['ParentID'] != 0){
            $Code .= "-".$this->getAccountCode(array('HeadID'=>$head[0]['ParentID']));
        }
        return $Code;
    }//end of getAccountCode

    function arrangeAccountCode($ParentCode){
        $ParentCode = explode("-",$ParentCode);
        $ParentCode = array_reverse($ParentCode);
        $ParentCode = implode("-",$ParentCode);
        return $ParentCode;
    }//end of arrangeAccountCode

    function generateAccountCode($HeadID){
        $ParentCode = $this->getAccountCode(array("HeadID"=>$HeadID));
        $ParentCode = $this->arrangeAccountCode($ParentCode);
        return $ParentCode;
    }

    function getAllInventoryUsers( $columns, $PTable, $joins='', $where='', $take='', $skip='', $order='',$group_by='',$where_in_filed='',$where_in_array='',$NotIn=''){

        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        //This foreach will run all the joins sent in array..
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype'],FALSE);
            }
        }
        if($where != ''){
            $this->db->where($where);
        }
        if($where_in_array != ''){
            $this->db->where_in($where_in_filed,$where_in_array);
        }
        if($NotIn != ''){
            $this->db->where_not_in('sys_user_accounts.EmployeeID',$NotIn);
        }
        if($take!='' && $skip!=''){
            $this->db->limit($take, $skip);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($order!=''){
            $this->db->order_by($order);
        }
        $query = $this->db->get();
        //echo  $this->db->last_query();
        return $query->result();
    }

    function countTotalInventoryUsers($columns, $PTable, $joins='', $where='',$field1='',$value1='',$group_by='',$where_in_filed='',$where_in_array='',$NotIn=''){
        $this->db->select($columns);
        $this->db->from($PTable); //this PTable is PrimaryTable for join Query
        if($joins!=''){
            foreach ($joins as $k => $v){
                $this->db->join($v['table'], $v['condition'], $v['jointype']);
            }
        }
        if($where!=''){
            $this->db->where($where);
        }
        if($where_in_array !=''){
            $this->db->where_in($where_in_filed,$where_in_array);
        }
        if($NotIn != ''){
            $this->db->where_not_in('sys_user_accounts.EmployeeID',$NotIn);
        }
        if($group_by!=''){
            $this->db->group_by($group_by);
        }
        if($field1!='' && $value1!=''){
            $this->db->like($field1, $value1);
        }
        $query = $this->db->get();
        //echo $this->db->last_query();
        return $query->num_rows();
    }
    //===============================================

    //GENERATE VOUCHER CODE
    function generateVoucherCode($VoucherTypeID=''){
        $voucherNumber = $this->getVoucherNumber($VoucherTypeID);
        $voucherCode  = date("Y")."-JV-".date("M")."-".$voucherNumber;
        return $voucherCode;
    }

    function getVoucherNumber($VoucherTypeID=''){
        $where = array('VoucherTypeID'=>$VoucherTypeID);

        $VoucherCode = $this->get_where_records('acc_voucher','VoucherNo',$where,'','VoucherID DESC');
        $VoucherCode = $VoucherCode[0]->VoucherNo;
        if(!$VoucherCode)
        {
            //$VoucherCode = $this->common_model->get_where_records('acc_voucher','VoucherNo',array('VoucherTypeID' => $this->input->post("VoucherTypeID")));
            //print_r($SubHeadCode);
            $VoucherCode = "000001";
        }
        else
        {
            $VoucherCode = str_pad((int) ++$VoucherCode, 6 ,"0",STR_PAD_LEFT);
        }
        return $VoucherCode;
    }

    function getFinancialYear($Date){
       $where = array(
            "\"StartDate\" <="=>date("Y-m-d",strtotime($Date)),
            "\"EndDate\" >="=>date("Y-m-d",strtotime($Date)),
       );
       $FYear = $this->get_where_records('acc_financial_year','FYearID',$where);
       return isset($FYear[0]->FYearID) ? $FYear[0]->FYearID : '';
    }

    function getDefaultCurrencyExchange(){
        $PTable = 'acc_currencies';
        $data   = 'ExchangeRateID';
        $where = array(
            "IsDefault"          =>1,
            "ExchangeRateStatus" => 1
        );
        $joins  = array(
            array(
                'table'     => 'acc_exchange_rates',
                'condition' => 'acc_exchange_rates.CurrencyID = acc_currencies.CurrencyID',
                'jointype'  => 'inner'
            )
        );
        $Currency = $this->get_where_records_joined($PTable,$data,$where, $joins);

        return $Currency[0]->ExchangeRateID;
    }

    function getDefaultCurrency(){
        $PTable = 'acc_currencies';
        $data   = 'CurrencyID';
        $where = array(
            "IsDefault"          =>1,
        );
        $Currency = $this->get_where_records_joined($PTable,$data,$where);

        return $Currency[0]->CurrencyID;
    }

    function getMappedDetailsAccID($MappingCode){
        $where = array(
            "MappingCode" => $MappingCode,
        );
        $detailAccID = $this->get_where_records('acc_mapping_accounts','DetailAccID',$where);
        return isset($detailAccID[0]->DetailAccID) ? $detailAccID[0]->DetailAccID : '';
    }

}//end of main class

