<?php
class file_download extends MY_Controller{

    //---  constructor function for class file_download  ---//
    function __construct(){
        parent::__construct();
        $this->load->helper('download');
    }//---  End of __construct  ---//


    //---  function for downloading vendor attachment copy  ---//
    function download_vendor_attachment($attachment){
        $data = file_get_contents(UPLOAD_IMS_VENDOR_ATTACHMENT.$attachment);
        force_download($attachment,$data);
    }//---  End of download_vendor_attachment  ---//

    function download_distributor_attachment($attachment){
        $data = file_get_contents(UPLOAD_IMS_DISTRIBUTOR_ATTACHMENT.$attachment);
        force_download($attachment,$data);
    }//---  End of download_vendor_attachment  ---//


    function download_product_attachment($attachment){
        $data = file_get_contents(UPLOAD_IMS_PRODUCT_ATTACHMENT.$attachment);
        force_download($attachment,$data);
    }//---  End of download_vendor_attachment  ---//


    //---  function for downloading workorder scan copy  ---//
    function download_workorder_attachment($scan_copy){
        $data = file_get_contents(UPLOADS_WORK_ORDER_COPIES.$scan_copy);
        force_download($scan_copy,$data);
    }//---  End of download_workorder_attachment  ---//


    //---  function for downloading customer attachment copy  ---//
    public function download_customer_attachment($attachment){
        $data = file_get_contents(UPLOADS_CRM_CUSTOMER_ATTACHMENT.$attachment);
        force_download($attachment,$data);
    }//---  End of function download_customer_attachment  ---//


    //---  function for downloading document version  ---//
    public function download_document_version($docVersionID){
        $url = base_url().UPLOADS_DMS_DOCUMENTS;
        $table = 'dms_documents_version';
        $columns = array('FileNameOnServer','FileNamePhysical');
        $where = array('DocVersionID' => $docVersionID);
        $result = $this->common_model->get_where_records($table, $columns, $where);


        $fileNameOnServer = $result[0]->FileNameOnServer;
        $fileNamePhysical = $result[0]->FileNamePhysical;
        //---  renaming file with original name  ---//
        //rename($url.$fileNameOnServer, $url.$fileNamePhysical);

        $data = file_get_contents(UPLOADS_DMS_DOCUMENTS.$fileNameOnServer);
        force_download($fileNameOnServer, $data);

        //rename($url.$fileNamePhysical,$url.$fileNameOnServer);
    }//---  End of function download_document_version  ---//


    //---  function for downloading project scan copy  ---//
    function download_project_scan_copy($scan_copy){
        $data = file_get_contents(UPLOADS_PROJECT_DETAILS_COPIES.$scan_copy);
        force_download($scan_copy,$data);
    }//---  End of download_project_scan_copy  ---//


    //---  function for downloading permit scan copy  ---//
    function download_permit_scan_copy($scan_copy){
        $data = file_get_contents(UPLOADS_PERMITS.$scan_copy);
        force_download($scan_copy,$data);
    }//---  End of download_permit_scan_copy  ---//


    //---  function for downloading permit renew scan copy  ---//
    function download_permit_renew_scan_copy($scan_copy){
        $data = file_get_contents(UPLOADS_PERMITS.$scan_copy);
        force_download($scan_copy,$data);
    }//---  End of download_permit_renew_scan_copy  ---//


    //---  function for downloading project scan copy  ---//
    function download_surveyor_attachment($attachment){
        $data = file_get_contents(UPLOADS_OSP_JOB_SURVEY.$attachment);
        force_download($attachment,$data);
    }//---  End of download_surveyor_attachment  ---//


    //---  function for download employee work permit  ---//
    public function download_work_permit($attachment){
        $data = file_get_contents(UPLOADS_EMP_WORK_PERMIT_COPIES.$attachment);
        force_download($attachment,$data);
    }//--- End of function download_work_permit  ---//


    //---  function for downloading employee cv copy  ---//
    function download_cv_copy($cv){
        $data = file_get_contents(UPLOADS_EMP_RESUMES_AND_CV.$cv);
        force_download($cv,$data);
    }//---  End of function download_cv_copy  ---//

    //---  function for downloading employee contract copy  ---//
    function download_contract_copy($contract_copy){
        $data = file_get_contents(UPLOADS_EMP_CONTRACT_COPIES.$contract_copy);
        force_download($contract_copy,$data);
    }//---  End of function download_contract_copy  ---//


    //---  function for downloading employee passport copy  ---//
    function download_passport_copy($passport_copy){
        $data = file_get_contents(UPLOADS_EMP_PASSPORT_COPIES.$passport_copy);
        force_download($passport_copy,$data);
    }//---  End of function download_passport_copy  ---//


    //---  function for download candidate cv copy  ---//
    public function download_candiate_cv_copy($cvCopy){
        $data = file_get_contents(UPLOADS_CANDIDATE_CV.$cvCopy);
        force_download($cvCopy, $data);

    }//---  End of function download_candidate_cv_copy  ---//


    //---  function for downloading number approval scan copy  ---//
    function number_approval_scancopy($scan_copy){
        $data = file_get_contents(UPLOADS_COORDINATION_NUMBER_APPROVAL.$scan_copy);
        force_download($scan_copy,$data);
    }//---  End of download_project_scan_copy  ---//


    //---  function for download full backup  ---//
    public function download_full_backup($backup){
        $data = file_get_contents(USER_UPLOAD_FOLDER_ROOT_BACKUPS.$backup);
        force_download($backup, $data);
    }//---  End of function download_full_backup  ---//

}//---  End of class file_download  ---//