<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*!
* HybridAuth
* http://hybridauth.sourceforge.net | http://github.com/hybridauth/hybridauth
* (c) 2009-2012, HybridAuth authors | http://hybridauth.sourceforge.net/licenses.html
*/

// ----------------------------------------------------------------------------------------
//	HybridAuth Config file: http://hybridauth.sourceforge.net/userguide/Configuration.html
// ----------------------------------------------------------------------------------------

$config =
	array(
		// set on "base_url" the relative url that point to HybridAuth Endpoint
		'base_url' => '/hauth/endpoint',

		"providers" => array (
			// openid providers
			"OpenID" => array (
				"enabled" => true
			),

			"Yahoo" => array (
				"enabled" => true,
				"keys"    => array ( "id" => "", "secret" => "" ),
			),

			"AOL"  => array (
				"enabled" => true
			),

			"Google" => array (
				"enabled" => true,
				/*"keys" => array(
					"id" => "214181804986-eca2s35q93b1uv95ke6749sbkni62mu0.apps.googleusercontent.com",
					"secret" => "GfdDT8l9_WErG1YODRAbjNgI"
				)*/
				"keys" => array(
					"id" => "1059831833739-53dbpo6jj320ig6h3qt9baebbqaugap3.apps.googleusercontent.com",
					"secret" => "owPJEnc2gUY0041Gs5ROx5v5"
				)

			),

			"Facebook" => array (
				"enabled" => true,
				"keys"    => array ( "id" => "368888860169753", "secret" => "45021e197bb34eb75c8fa22d17d5097c" ),
				"scope" => "publish_actions"
			),

			"Twitter" => array (
				"enabled" => true,
				"keys"    => array ( "key" => "2aNE2rCz8AC9OaYqql1uJ0Zsk", "secret" => "qAdWdaUyvREpzVOdZcVJMMjU5JUDJZgC8Dyx1fx6W3X0kVqefm" )
			),

			// windows live
			"Live" => array (
				"enabled" => true,
				"keys"    => array ( "id" => "", "secret" => "" )
			),

			"MySpace" => array (
				"enabled" => true,
				"keys"    => array ( "key" => "", "secret" => "" )
			),

			"LinkedIn" => array (
				"enabled" => true,
				"keys"    => array ( "key" => "", "secret" => "" )
			),

			"Foursquare" => array (
				"enabled" => true,
				"keys"    => array ( "id" => "", "secret" => "" )
			),
		),

		// if you want to enable logging, set 'debug_mode' to true  then provide a writable file by the web server on "debug_file"
		"debug_mode" => (ENVIRONMENT == 'development'),

		"debug_file" => APPPATH.'/logs/hybridauth.log',
	);


/* End of file hybridauthlib.php */
/* Location: ./application/config/hybridauthlib.php */